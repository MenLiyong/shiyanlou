#!/usr/bin/env python3
import sys

argvs = sys.argv[1:]
configfilepath_value = ''
salaryfilepath_value = ''

for i,j in enumerate(sys.argv):
    if(i == 0):
        continue
    if(i == 2):
        configfilepath=j
    if(i == 4):
        salaryfilepath=j
 
#print(configfilepath) 
file1_value = ''
file2_value = ''
JishuH = ''
JiShuL = ''
YangLao = ''
Yiliao = ''
ShiYe = ''
GongShang = ''
ShengYu = ''
GongJiJin = ''
with open(configfilepath, 'r') as file:
    for line in file:
        j = line.split('=')
        j[0] = j[0].strip(' ')
        j[1] = j[1].strip(' ')
        j[1] = j[1].strip('\n')
        JishuH = 
        if j[0] == 'JiShuH':
            JishuH = j[1]
        elif j[0] == 'JiShuL':
            JishuL = j[1]
        elif j[0] == 'YangLao':
            YangLao = j[1]
        elif j[0] == 'Yiliao':
            YiLiao = j[1]
        elif j[0] == 'ShiYe':
            ShiYe = j[1]
        elif j[0] == 'GongShang':
            GongShang = j[1]
        elif j[0] == 'ShengYu':
            ShengYu = j[1] 
        elif j[0] == 'GongJiJin':
            GongJiJin = j[1] 
        print(j)





#print(salaryfilepath)
with open(salaryfilepath,'r') as file2:
    print(file2.read()) 
    for i in file2:
        j = i.split(':')
        try:
            j[1] = cal(int(j[1]))
        except ValueError:
            print('Parameter Error')



                                                    

