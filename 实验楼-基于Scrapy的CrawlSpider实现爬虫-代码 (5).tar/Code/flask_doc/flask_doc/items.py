# -*- coding: utf-8 -*-
import scrapy


class PageItem(scrapy.Item):
    # define the fields for your item here like:
    url = scrapy.Field()
    text = scrapy.Field()
