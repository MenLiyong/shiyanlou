# -*- coding:utf-8 -*-

from openpyxl import Workbook,load_workbook
import datetime

def combine(filepath):
    wb = load_workbook(filename=filepath)
    wc = wb.create_sheet('combine')
    ws = wb['students']
    wt = wb['time']
    wc.append(['创建时间', '课程名称', '学习人数','学习时间'])
        
    for a,b in zip(list(ws.values)[1:],list(wt.values)[1:]):
        wc.append(list(a)+[b[-1]])
    wb.save(filepath)
    return wc

def split(wc):
    s = set()
    for i in list(wc.values)[1:]:
        s.add(i[0].strftime('%Y'))

    for year in s:
        wb = Workbook()
        ws = wb.active
        ws.title = year
        ws.append(['创建时间', '课程名称', '学习人数', '学习时间'])
        for i in list(wc.values)[1:]:
            if i[0].strftime('%Y') == year:
                ws.append(i)
        wb.save('{}.xlsx'.format(year))

if __name__ == '__main__':
    filepath = "/home/shiyanlou/Code/courses.xlsx"    
    split(combine(filepath))

