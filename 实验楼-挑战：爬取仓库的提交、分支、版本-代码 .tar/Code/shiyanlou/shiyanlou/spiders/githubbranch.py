# -*- coding: utf-8 -*-
import scrapy
from shiyanlou.items import GithubBranchItem

class GithubbranchSpider(scrapy.Spider):
    name = 'githubbranch'
    start_urls = ['https://github.com/']

    @property
    def start_urls(self):
        url_tmpl = 'https://github.com/shiyanlou?page={}&tab=repositories'
        return (url_tmpl.format(i) for i in range(1, 5))

    def parse(self, response):
        for i in response.css('li.col-12'):
            item = GithubBranchItem()
            item['name'] = i.xpath('.//div[@class="d-inline-block mb-1"]/h3/a/@href').re('/shiyanlou/(.+)'),
            item['update_time'] = i.xpath('.//div[3]/relative-time/@datetime').extract()
            i_url = response.urljoin(i.xpath('.//div[@class="d-inline-block mb-1"]/h3/a/@href').extract_first())
            request = scrapy.Request(i_url, callback=self.parse_branch)
            request.meta['item'] = item
            yield request

    def parse_branch(self,response):
        item = response.meta['item']
        item_a = response.xpath('.//span[contains(@class,"text-emphasized")]/text()').re('[^\d]*(\d+)[^\d]*')
        if item_a != []:
            print('-------------------------------------', item_a)
            item['commits'] = item_a[0]
            item['branches'] = item_a[1]
            item['releases'] = item_a[2]
            yield item            
