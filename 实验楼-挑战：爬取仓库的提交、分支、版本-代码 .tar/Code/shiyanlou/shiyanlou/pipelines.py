# -*- coding: utf-8 -*-
from datetime import datetime
from sqlalchemy.orm import sessionmaker
from shiyanlou.models import Repository,engine
from shiyanlou.items import GithubBranchItem
import re

class ShiyanlouPipeline(object):

    def process_item(self, item, spider):
        item['commits'] = int(re.sub(',','',item['commits']))
        item['branches'] = int(re.sub(',','',item['branches']))
        item['releases'] = int(re.sub(',','',item['releases']))
        self.session.add(Repository(**item))

    def open_spider(self,spider):
        Session = sessionmaker(bind=engine)
        self.session = Session()
        
    def close_spider(self,spider):
        self.session.commit()
        self.session.close()
