# -*- coding: utf-8 -*-
import re
import redis
import json


class DoubanMoviePipeline(object):

    def process_item(self, item, spider):
        #item = json.dumps(dict(item),encoding='utf-8',ensure_ascii=False)
        item = json.dumps(dict(item))
        self.redis.lpush("douban_movie:items", item)
        return item

    def open_spider(self,spider):
        self.redis = redis.StrictRedis(host='localhost',port=6379,db=0)