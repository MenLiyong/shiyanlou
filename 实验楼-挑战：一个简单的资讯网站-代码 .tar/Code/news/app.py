# -*- coding:utf-8 -*-
from flask import Flask, render_template,abort
import os,sys
import json

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True

@app.route('/')
def index():
    news_list = os.listdir('/home/shiyanlou/files/')
    return render_template('index.html', news_list=news_list)

@app.route('/files/<filename>')
def file(filename):
    try:
        with open('/home/shiyanlou/files/'+filename+'.json', 'r') as file:
            news = json.loads(file.read()) 
            news = {
                'title':news['title'],
                'created_time':news['created_time'],
                'content':news['content']
            }
            return render_template('file.html', news=news)
    except FileNotFoundError:
        return render_template('404.html'),404

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404
