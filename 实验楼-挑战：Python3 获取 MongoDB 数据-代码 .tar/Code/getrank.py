 # -*- coding: utf-8 -*-
import sys
from pymongo import MongoClient

def get_rank(user_id):
    client = MongoClient("127.0.0.1",27017)
    db = client.shiyanlou

    data_after_aggregate = db.contests.aggregate([
    {'$group':{'_id':'$user_id',
               'score':{'$sum':'$score'},
               'submit_time':{'$sum':'$submit_time'}
    }},    
    {'$sort':{'submit_time':1}},
    {'$sort':{'score':-1}}
    ])
# dict maybe change sort sequence itself! So one sentence was divided into two.

    for a, b in enumerate(list(data_after_aggregate)):
        if user_id == b.get('_id'):
            return a+1, b['score'], b['submit_time']

try:
    result = get_rank(int(sys.argv[1]))
    if result:
        print(result)
    else:
        print('Parameter Error')              
except:
    print('Parameter Error')