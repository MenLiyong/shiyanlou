# -*- coding: utf-8 -*-

import scrapy


class ShiyanloucrwalgithubItem(scrapy.Item):
    # define the fields for your item here like:
    name = scrapy.Field()
    update_time = scrapy.Field()
