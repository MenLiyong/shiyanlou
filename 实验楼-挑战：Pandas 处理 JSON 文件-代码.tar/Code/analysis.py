import json, os, sys
import pandas as pd

def analysis(file, user_id):
    times = 0 
    minutes = 0
    df = pd.read_json(file)

    if user_id in df['user_id'].values:
        dd = df[df['user_id']==user_id]
        return len(dd), dd.minutes.sum()

if __name__ == '__main__':

    file = sys.argv[1]
    user_id = int(sys.argv[2])
    if os.path.exists(file):
        if user_id:
            print(analysis(file, user_id))
        else:
            print('Pls enter user_id ')
    else:
        print('File not exists')








