class Animal:
    owner = 'jack'
    
    def __init__(self, name):
        self.name = name
    
    def get_name(self):
        return self._name.lower().capitalize()
    
    def set_name(self, value):
        self._name = value
    
    def make_sound(self):
        pass
    
    @classmethod
    def get_owner(cls);
        return cls.owner
    
    @property 
    def age(self):
        return self._age
    
    @age.setter
    def age(self,value):
        if isinstance(value, int):
            self._age = value
        else:
            raise ValueError

    @staticmethod
    def order_animal_food():
        print('ording...')
        print('ok')


class Dog (Animal):
    def make_sound(self):
        print(self.get_name() + 'is making sound wang wang wang...')


class Cat(Animal):
    owner = 'Lisa'
    
    def make_sound(self):
        print(self.get_name() + 'is making sound miu miu miu...')